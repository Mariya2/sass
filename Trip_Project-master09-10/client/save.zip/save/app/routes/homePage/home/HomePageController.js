/**
 * 
 */
travelAssistant.controller("HomePageController",
		['$scope', 'userService', '$http',
		 function HomePageController($scope, userService, $http){
			
			
		}])